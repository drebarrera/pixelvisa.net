<?php
/*
Template Name: Destinations Page
*/
get_header();
?>
<section id="destinations-section">
    <div class="content">
    
    </div>
</section>
<?php get_footer();