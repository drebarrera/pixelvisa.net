<?php
/*
Template Name: Map Page
*/
get_header();
?>
<section id="map-section">
    <div class="content">
        <div id="map"></div>
        <div id="panel"></div>
    </div>
</section>
<?php get_footer();