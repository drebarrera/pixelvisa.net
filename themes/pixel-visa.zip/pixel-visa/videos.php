<?php
/*
Template Name: Videos Page
*/
get_header();
?>
<section id="videos-section">
    <div class="content">
    
    </div>
</section>
<?php get_footer();